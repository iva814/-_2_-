import arcade
import random
import math

SCREEN_WIDTH = 1000
SCREEN_HEIGHT = 700
SCREEN_TITLE = "КОСМИЧЕСКИЙ ЩИТ"

SHIELD_WIDTH = 120
SHIELD_HEIGHT = 25
SHIELD_SPEED = 10

# Цвета
BACKGROUND_COLOR = (10, 10, 30)
EARTH_COLOR = (30, 180, 100)

# Параметры игры
MAX_LIVES = 3
INITIAL_LEVEL = 1
SCORE_PER_LEVEL = 1000

# Метеориты
METEOR_SIZES = ["small", "medium", "large"]
METEOR_SPEEDS = {
    "small": {"min": 4, "max": 6},
    "medium": {"min": 3, "max": 5},
    "large": {"min": 2, "max": 4}
}
METEOR_SCORES = {
    "small": 150,
    "medium": 100,
    "large": 50
}
METEOR_SPAWN_CHANCE = 0.03  # Шанс спавна метеорита каждый кадр

# Частицы
PARTICLE_COUNT = 15


# ========== КЛАССЫ ==========
class Shield(arcade.Sprite):
    """Щит игрока"""

    def __init__(self):
        # Используем текстуру из ресурсов arcade
        super().__init__(":resources:images/space_shooter/playerShip1_orange.png", 0.5)
        self.center_x = SCREEN_WIDTH // 2
        self.center_y = 50
        self.width = SHIELD_WIDTH
        self.height = SHIELD_HEIGHT
        self.angle = 90  # Поворачиваем корабль для горизонтального положения

    def draw(self):
        super().draw()
        # Добавляем эффект свечения
        arcade.draw_rectangle_outline(
            self.center_x, self.center_y,
            self.width, self.height,
            arcade.color.CYAN, 2
        )


class Meteor(arcade.Sprite):
    """Метеорит"""

    def __init__(self, level):
        # Используем текстуру астероида из ресурсов
        super().__init__(":resources:images/space_shooter/meteorGrey_big1.png", 0.5)

        self.size = random.choice(METEOR_SIZES)
        # Масштабируем в зависимости от размера
        if self.size == "small":
            self.scale = 0.3
        elif self.size == "medium":
            self.scale = 0.5
        else:  # large
            self.scale = 0.7

        self.score = METEOR_SCORES[self.size]

        # Скорость увеличивается с уровнем
        speed_mult = 1 + (level - 1) * 0.1
        min_speed = METEOR_SPEEDS[self.size]["min"] * speed_mult
        max_speed = METEOR_SPEEDS[self.size]["max"] * speed_mult
        self.speed = random.uniform(min_speed, max_speed)

        # Позиция
        self.center_x = random.randint(50, SCREEN_WIDTH - 50)
        self.center_y = SCREEN_HEIGHT + 50

        # Вращение
        self.change_angle = random.uniform(-2, 2)

    def update(self):
        """Обновление позиции"""
        self.center_y -= self.speed
        self.angle += self.change_angle


class Particle:
    """Частица для эффектов"""

    def __init__(self, x, y, color):
        self.x = x
        self.y = y
        self.color = color
        self.size = random.uniform(2, 5)
        self.speed_x = random.uniform(-3, 3)
        self.speed_y = random.uniform(-3, 3)
        self.life = 1.0
        self.decay = random.uniform(0.02, 0.05)

    def update(self):
        """Обновление частицы"""
        self.x += self.speed_x
        self.y += self.speed_y
        self.life -= self.decay
        self.speed_y -= 0.1  # Гравитация

    def draw(self):
        """Отрисовка частицы"""
        if self.life > 0:
            alpha = int(self.life * 255)
            arcade.draw_circle_filled(
                self.x, self.y, self.size,
                (self.color[0], self.color[1], self.color[2], alpha)
            )


# ========== ОСНОВНОЙ КЛАСС ИГРЫ ==========
class CosmicShield(arcade.Window):
    def __init__(self):
        super().__init__(SCREEN_WIDTH, SCREEN_HEIGHT, SCREEN_TITLE)

        # Игровые объекты
        self.shield = None
        self.meteor_list = None
        self.particles = []

        # Состояние игры
        self.score = 0
        self.level = INITIAL_LEVEL
        self.lives = MAX_LIVES
        self.game_over = False
        self.paused = False

        # Эффекты
        self.screen_shake = 0
        self.combo = 0
        self.combo_timeout = 0

        # Звуки
        self.sound_enabled = False

        # Спрайт-листы для оптимизации
        self.setup()

    def setup(self):
        """Настройка новой игры"""
        # Инициализация спрайт-листов
        self.meteor_list = arcade.SpriteList()

        # Создание щита
        self.shield = Shield()

        # Очистка частиц
        self.particles.clear()

        # Сброс состояния игры
        self.score = 0
        self.level = INITIAL_LEVEL
        self.lives = MAX_LIVES
        self.game_over = False
        self.paused = False

        self.combo = 0
        self.combo_timeout = 0

    def on_draw(self):
        """Отрисовка кадра"""
        self.clear(BACKGROUND_COLOR)

        # Звездный фон
        self.draw_stars()

        # Земля
        self.draw_earth()

        # Игровые объекты
        self.meteor_list.draw()
        self.shield.draw()

        # Частицы
        for particle in self.particles:
            particle.draw()

        # Интерфейс
        self.draw_ui()

        # Пауза или Game Over
        if self.paused:
            self.draw_pause_screen()
        elif self.game_over:
            self.draw_game_over_screen()

    def draw_stars(self):
        """Отрисовка звездного фона"""
        for i in range(100):
            x = (i * 13) % SCREEN_WIDTH
            y = (i * 11) % SCREEN_HEIGHT
            size = 1 + (i % 3)
            brightness = 150 + (i % 105)
            arcade.draw_circle_filled(
                x, y, size,
                (brightness, brightness, brightness)
            )

    def draw_earth(self):
        """Отрисовка Земли внизу экрана"""
        # Земля
        arcade.draw_rectangle_filled(
            SCREEN_WIDTH // 2, 75,
            SCREEN_WIDTH, 150,
            arcade.color.DARK_GREEN
        )

        # Континенты
        arcade.draw_ellipse_filled(
            300, 75, 250, 50,
            arcade.color.GREEN
        )
        arcade.draw_ellipse_filled(
            700, 75, 200, 45,
            arcade.color.FOREST_GREEN
        )

    def draw_ui(self):
        """Отрисовка интерфейса"""
        # Счет и уровень
        arcade.draw_text(
            f"СЧЁТ: {self.score}",
            20, SCREEN_HEIGHT - 40,
            arcade.color.WHITE, 28
        )

        arcade.draw_text(
            f"УРОВЕНЬ: {self.level}",
            20, SCREEN_HEIGHT - 80,
            arcade.color.CYAN, 24
        )

        # Жизни
        lives_text = "ЖИЗНИ: " + "❤️ " * self.lives
        arcade.draw_text(
            lives_text,
            SCREEN_WIDTH - 200, SCREEN_HEIGHT - 40,
            arcade.color.RED, 28
        )

        # Комбо
        if self.combo > 1:
            combo_color = (
                255,
                max(0, 255 - self.combo * 20),
                0
            )
            arcade.draw_text(
                f"COMBO x{self.combo}!",
                SCREEN_WIDTH // 2, SCREEN_HEIGHT - 120,
                combo_color, 36,
                anchor_x="center"
            )

        # Прогресс уровня
        progress = (self.score % SCORE_PER_LEVEL) / SCORE_PER_LEVEL
        bar_width = 400

        # Фон прогресс-бара
        arcade.draw_rectangle_filled(
            SCREEN_WIDTH // 2, 50,
            bar_width, 20,
            arcade.color.DARK_GRAY
        )

        # Заполненная часть
        if progress > 0:
            arcade.draw_rectangle_filled(
                SCREEN_WIDTH // 2 - bar_width // 2 + (bar_width * progress) / 2,
                50,
                bar_width * progress,
                20,
                arcade.color.GOLD
            )

        # Обводка
        arcade.draw_rectangle_outline(
            SCREEN_WIDTH // 2, 50,
            bar_width, 20,
            arcade.color.WHITE, 2
        )

        # Подсказки управления
        arcade.draw_text(
            "← → или A D - движение | P - пауза | R - рестарт | ESC - выход",
            SCREEN_WIDTH // 2, 20,
            arcade.color.LIGHT_GRAY, 14,
            anchor_x="center"
        )

    def draw_pause_screen(self):
        """Экран паузы"""
        # Полупрозрачный фон
        arcade.draw_rectangle_filled(
            SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2,
            SCREEN_WIDTH, SCREEN_HEIGHT,
            (0, 0, 0, 180)
        )

        # Текст
        arcade.draw_text(
            "ПАУЗА",
            SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 50,
            arcade.color.WHITE, 48,
            anchor_x="center", anchor_y="center"
        )

        arcade.draw_text(
            "Нажмите P чтобы продолжить",
            SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 - 30,
            arcade.color.LIGHT_GRAY, 24,
            anchor_x="center", anchor_y="center"
        )

    def draw_game_over_screen(self):
        """Экран окончания игры"""
        # Полупрозрачный фон
        arcade.draw_rectangle_filled(
            SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2,
            SCREEN_WIDTH, SCREEN_HEIGHT,
            (0, 0, 0, 220)
        )

        # Текст
        arcade.draw_text(
            "ИГРА ОКОНЧЕНА",
            SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 80,
            arcade.color.RED, 48,
            anchor_x="center", anchor_y="center"
        )

        arcade.draw_text(
            f"Финальный счёт: {self.score}",
            SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 20,
            arcade.color.WHITE, 36,
            anchor_x="center", anchor_y="center"
        )

        arcade.draw_text(
            f"Достигнутый уровень: {self.level}",
            SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 - 20,
            arcade.color.CYAN, 28,
            anchor_x="center", anchor_y="center"
        )

        arcade.draw_text(
            "Нажмите R для перезапуска",
            SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 - 80,
            arcade.color.LIGHT_GRAY, 24,
            anchor_x="center", anchor_y="center"
        )

    def on_update(self, delta_time):
        """Обновление игровой логики"""
        if self.game_over or self.paused:
            return

        # Обновление таймера комбо
        if self.combo_timeout > 0:
            self.combo_timeout -= 1
            if self.combo_timeout == 0:
                self.combo = 0

        # Движение щита
        self.update_shield()

        # Обновление метеоритов
        self.meteor_list.update()

        # Создание новых метеоритов
        self.spawn_meteors()

        # Обновление частиц
        self.update_particles()

        # Проверка столкновений
        self.check_collisions()

        # Проверка уровня
        self.check_level_up()

    def update_shield(self):
        """Обновление положения щита"""
        # Ограничение движения в пределах экрана
        self.shield.center_x = max(
            self.shield.width / 2,
            min(
                SCREEN_WIDTH - self.shield.width / 2,
                self.shield.center_x
            )
        )

    def spawn_meteors(self):
        """Создание новых метеоритов"""
        # Шанс спавна увеличивается с уровнем
        spawn_chance = METEOR_SPAWN_CHANCE + (self.level - 1) * 0.01

        if random.random() < spawn_chance:
            meteor = Meteor(self.level)
            self.meteor_list.append(meteor)

    def update_particles(self):
        """Обновление частиц"""
        particles_to_remove = []

        for particle in self.particles:
            particle.update()
            if particle.life <= 0:
                particles_to_remove.append(particle)

        # Удаление "мертвых" частиц
        for particle in particles_to_remove:
            self.particles.remove(particle)

    def check_collisions(self):
        """Проверка столкновений"""
        # Проверка столкновений с щитом
        hit_list = arcade.check_for_collision_with_list(self.shield, self.meteor_list)

        for meteor in hit_list:
            # Попадание!
            base_score = meteor.score
            combo_bonus = base_score * (self.combo * 0.2)
            total_score = int(base_score + combo_bonus)

            self.score += total_score
            self.combo += 1
            self.combo_timeout = 90

            # Удаление метеорита
            meteor.remove_from_sprite_lists()

            # Частицы взрыва
            colors = [
                (255, 200, 100),  # Золотой
                (255, 150, 50),  # Оранжевый
                (200, 100, 50)  # Коричневый
            ]

            for _ in range(PARTICLE_COUNT):
                color = random.choice(colors)
                particle = Particle(meteor.center_x, meteor.center_y, color)
                self.particles.append(particle)

        # Проверка метеоритов, упавших на землю
        for meteor in self.meteor_list:
            if meteor.center_y < 0:
                meteor.remove_from_sprite_lists()
                self.lives -= 1
                self.combo = 0

                # Частицы промаха
                colors = [
                    (255, 50, 50),  # Красный
                    (200, 30, 30),  # Темно-красный
                    (150, 20, 20)  # Бордовый
                ]

                for _ in range(PARTICLE_COUNT // 2):
                    color = random.choice(colors)
                    particle = Particle(meteor.center_x, meteor.center_y, color)
                    self.particles.append(particle)

                if self.lives <= 0:
                    self.game_over = True

    def check_level_up(self):
        """Проверка повышения уровня"""
        if self.score >= self.level * SCORE_PER_LEVEL:
            self.level += 1

            # Эффект повышения уровня
            for _ in range(30):
                color = random.choice([
                    (255, 255, 100),  # Желтый
                    (100, 255, 255),  # Голубой
                    (255, 100, 255)  # Фиолетовый
                ])
                particle = Particle(
                    SCREEN_WIDTH // 2,
                    SCREEN_HEIGHT // 2,
                    color
                )
                particle.speed_y = abs(particle.speed_y)
                self.particles.append(particle)

    def on_key_press(self, key, modifiers):
        """Обработка нажатия клавиш"""
        if key == arcade.key.LEFT or key == arcade.key.A:
            self.shield.center_x -= SHIELD_SPEED
        elif key == arcade.key.RIGHT or key == arcade.key.D:
            self.shield.center_x += SHIELD_SPEED
        elif key == arcade.key.P:
            self.paused = not self.paused
        elif key == arcade.key.R:
            self.setup()
        elif key == arcade.key.ESCAPE:
            self.close()

    def on_mouse_motion(self, x, y, dx, dy):
        """Движение мыши (альтернативное управление)"""
        if not self.game_over and not self.paused:
            self.shield.center_x = x


# ========== ЗАПУСК ИГРЫ ==========
def main():
    """Запуск игры"""
    window = CosmicShield()
    window.setup()
    arcade.run()


if __name__ == "__main__":
    main()